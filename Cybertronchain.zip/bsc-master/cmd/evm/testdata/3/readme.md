These files examplify a transition where a transaction (excuted on block 5) requests
the blockhash for block `1`. 
